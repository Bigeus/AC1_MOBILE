package com.example.filmesac1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Aplique padding no layout conforme a altura das barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Inicializando o BancoHelper para adicionar os filmes
        BancoHelper bancoHelper = new BancoHelper(this);

        // Adicionando 3 filmes no banco
     //   addSampleMovies(bancoHelper);

        Button btnAddMovie = findViewById(R.id.btnAddMovie);
        btnAddMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar para a tela de cadastro de filme
                Intent intent = new Intent(MainActivity.this, CreateBook.class);
                startActivity(intent);
            }
        });

        Button btnListMovie = findViewById(R.id.btnListMovie);
        btnListMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar para a tela de listagem de filmes
                Intent intent02 = new Intent(MainActivity.this, ListMovies.class);
                startActivity(intent02);
            }
        });
    }


//    private void addSampleMovies(BancoHelper bancoHelper) {
//        bancoHelper.insertBook("Inception", "Christopher Nolan", "2010", 5, "Ficção", true);
//        bancoHelper.insertBook("The Dark Knight", "Christopher Nolan", "2008", 5, "Ação", true);
//        bancoHelper.insertBook("Forrest Gump", "Robert Zemeckis", "1994", 5, "Drama", false);
//    }
}
