package com.example.filmesac1;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateBook extends AppCompatActivity {

    private EditText etTitle, etDirector, etYearLaunch;
    private RatingBar ratingBar;
    private Spinner spinnerGenre;
    private CheckBox cbSeenInTheatre;
    private Button btnSave;
    private BancoHelper bancoHelper;
    private int movieId = -1; // Variável para armazenar o ID do filme

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Layout principal (LinearLayout)
        LinearLayout mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(16, 16, 16, 16);

        // Título do Filme
        etTitle = new EditText(this);
        etTitle.setHint("Título");
        etTitle.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(etTitle);

        // Diretor do Filme
        etDirector = new EditText(this);
        etDirector.setHint("Diretor");
        etDirector.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(etDirector);

        // Ano de Lançamento
        etYearLaunch = new EditText(this);
        etYearLaunch.setHint("Ano de Lançamento");
        etYearLaunch.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        etYearLaunch.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(etYearLaunch);

        // Nota Pessoal (RatingBar)
        ratingBar = new RatingBar(this);
        ratingBar.setNumStars(5);
        ratingBar.setStepSize(1);
        ratingBar.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(ratingBar);

        // Gênero do Filme (Spinner)
        spinnerGenre = new Spinner(this);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.genres_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGenre.setAdapter(adapter);
        spinnerGenre.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(spinnerGenre);

        // Já vi no cinema (CheckBox)
        cbSeenInTheatre = new CheckBox(this);
        cbSeenInTheatre.setText("Já vi no cinema?");
        cbSeenInTheatre.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(cbSeenInTheatre);

        // Botão Salvar
        btnSave = new Button(this);
        btnSave.setText("Salvar");
        btnSave.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        mainLayout.addView(btnSave);

        // Configurar o banco de dados
        bancoHelper = new BancoHelper(this);

        // Definir o layout da Activity
        setContentView(mainLayout);

        // Verificar se um ID de filme foi passado para esta Activity
        if (getIntent().hasExtra("movieId")) {
            movieId = getIntent().getIntExtra("movieId", -1);
            loadMovieDetails(movieId); // Carregar os detalhes do filme para edição
        }

        // Ação do botão Salvar
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Recuperando os valores inseridos
                String title = etTitle.getText().toString();
                String director = etDirector.getText().toString();
                String yearLaunch = etYearLaunch.getText().toString();
                int starsScore = (int) ratingBar.getRating();
                String genre = spinnerGenre.getSelectedItem().toString();
                Boolean seenInTheatre = cbSeenInTheatre.isChecked();

                if (movieId == -1) {
                    // Inserir novo filme
                    long result = bancoHelper.insertBook(title, director, yearLaunch, starsScore, genre, seenInTheatre);
                    if (result != -1) {
                        Toast.makeText(CreateBook.this, "Filme salvo com sucesso!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(CreateBook.this, "Erro ao salvar o filme.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Atualizar filme existente
                    int result = bancoHelper.updateBook(movieId, title, director, yearLaunch, starsScore, genre, seenInTheatre);
                    if (result > 0) {
                        Toast.makeText(CreateBook.this, "Filme atualizado com sucesso!", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(CreateBook.this, "Erro ao atualizar o filme.", Toast.LENGTH_SHORT).show();
                    }
                }

                finish(); // Fechar a Activity e voltar para a anterior
            }
        });
    }

    // Carregar os detalhes do filme para edição
    private void loadMovieDetails(int movieId) {
        // Recuperar os detalhes do filme a partir do banco de dados
        Cursor cursor = bancoHelper.getMovieById(movieId);

        if (cursor != null && cursor.moveToFirst()) {
            // Preencher os campos com os dados do filme
            String title = cursor.getString(cursor.getColumnIndex("title"));
            String director = cursor.getString(cursor.getColumnIndex("director"));
            String yearLaunch = cursor.getString(cursor.getColumnIndex("yearLaunch"));
            int starsScore = cursor.getInt(cursor.getColumnIndex("starsScore"));
            String genre = cursor.getString(cursor.getColumnIndex("genre"));
            boolean seenInTheatre = cursor.getInt(cursor.getColumnIndex("seenInTheatre")) > 0;

            // Preencher os campos no layout
            etTitle.setText(title);
            etDirector.setText(director);
            etYearLaunch.setText(yearLaunch);
            ratingBar.setRating(starsScore);
            cbSeenInTheatre.setChecked(seenInTheatre);

            // Selecionar o gênero no Spinner
            ArrayAdapter adapter = (ArrayAdapter) spinnerGenre.getAdapter();
            int genrePosition = adapter.getPosition(genre);
            spinnerGenre.setSelection(genrePosition);
        }

        if (cursor != null) {
            cursor.close();
        }
    }
}
