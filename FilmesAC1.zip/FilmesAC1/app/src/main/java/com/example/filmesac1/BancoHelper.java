package com.example.filmesac1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BancoHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "mydb.db";
    private static final int DATABASE_VERSION = 1;
    // TABELA DE LIVROS
    private static final String TABLE_NAME = "books";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DIRECTOR = "director";
    private static final String COLUMN_YEAR_LAUNCH = "yearLaunch";
    private static final String COLUMN_STARS_SCORE = "starsScore";
    private static final String COLUMN_GENRE = "genre";
    private static final String COLUMN_SEEN_IN_THEATRE = "seenInTheatre";


    public BancoHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_TITLE + " TEXT, "
                + COLUMN_DIRECTOR + " TEXT, "
                + COLUMN_YEAR_LAUNCH + " TEXT, "
                + COLUMN_STARS_SCORE + " NUMBER, "
                + COLUMN_GENRE + " TEXT, "
                + COLUMN_SEEN_IN_THEATRE + " BOOLEAN)";
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public long insertBook(String title, String director, String yearLaunch, int starsScore, String genre, Boolean seenInTheatre){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_TITLE, title);
        contentValues.put(COLUMN_DIRECTOR, director);
        contentValues.put(COLUMN_YEAR_LAUNCH, yearLaunch);
        contentValues.put(COLUMN_STARS_SCORE, starsScore);
        contentValues.put(COLUMN_GENRE, genre);
        contentValues.put(COLUMN_SEEN_IN_THEATRE, seenInTheatre ? 1 : 0);  // Convertendo o valor Boolean para 1 ou 0
        return db.insert(TABLE_NAME, null, contentValues);
    }


    public Cursor listBooks(){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    public int updateBook(int id, String title, String director, String yearLaunch, int starsScore, String genre, Boolean seenInTheatre){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_TITLE, title);
        contentValues.put(COLUMN_DIRECTOR, director);
        contentValues.put(COLUMN_YEAR_LAUNCH, yearLaunch);
        contentValues.put(COLUMN_STARS_SCORE, starsScore);
        contentValues.put(COLUMN_GENRE, genre);
        contentValues.put(COLUMN_SEEN_IN_THEATRE, seenInTheatre);
        return db.update(TABLE_NAME, contentValues, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public int deleteBook(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public Cursor getMovieById(int movieId) {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_ID + " = ?", new String[]{String.valueOf(movieId)});
    }

}
