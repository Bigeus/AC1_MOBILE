package com.example.filmesac1;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListMovies extends AppCompatActivity {

    private ListView listViewMovies;
    private Spinner spinnerGenreFilter;
    private ArrayList<String> moviesList;
    private BancoHelper bancoHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_movies);

        bancoHelper = new BancoHelper(this);
        listViewMovies = findViewById(R.id.listViewMovies);
        spinnerGenreFilter = findViewById(R.id.spinnerGenreFilter);
        moviesList = new ArrayList<>();

        // Configurando o Spinner de gênero com as opções de filtro
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.movie_genres, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGenreFilter.setAdapter(adapter);

        // Carregar todos os filmes no banco de dados
        loadMoviesFromDatabase();

        // Filtrar por gênero
        spinnerGenreFilter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedGenre = parentView.getItemAtPosition(position).toString();
                filterMoviesByGenre(selectedGenre);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                filterMoviesByGenre("Todos");
            }
        });

        // Ação de adicionar novo filme
        Button btnAddMovie = findViewById(R.id.btnAddMovie);
        btnAddMovie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar para a tela de criação de filme
                Intent intent = new Intent(ListMovies.this, CreateBook.class);
                startActivity(intent);
            }
        });

        // Ação de clique longo para excluir filme
        listViewMovies.setOnItemLongClickListener((parent, view, position, id) -> {
            String movieDetails = moviesList.get(position);
            String movieId = movieDetails.split(" - ")[0]; // O ID do filme está no início da string
            showDeleteConfirmationDialog(Integer.parseInt(movieId));
            return true; // Indica que o clique longo foi consumido
        });

        // Ação de clique curto para editar filme
        listViewMovies.setOnItemClickListener((parent, view, position, id) -> {
            String movieDetails = moviesList.get(position);
            String movieId = movieDetails.split(" - ")[0]; // O ID do filme está no início da string
            // Navegar para a tela de edição de filme
            Intent intent = new Intent(ListMovies.this, CreateBook.class);
            intent.putExtra("movieId", Integer.parseInt(movieId));
            startActivity(intent);
        });
    }

    // Carregar todos os filmes do banco de dados
    private void loadMoviesFromDatabase() {
        Cursor cursor = bancoHelper.listBooks();
        moviesList.clear();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String title = cursor.getString(cursor.getColumnIndex("title"));
                String yearLaunch = cursor.getString(cursor.getColumnIndex("yearLaunch"));
                int starsScore = cursor.getInt(cursor.getColumnIndex("starsScore"));
                String genre = cursor.getString(cursor.getColumnIndex("genre"));

                String movie = id + " - " + title + " (" + yearLaunch + ") - " + starsScore + " estrelas - " + genre;
                moviesList.add(movie);
            } while (cursor.moveToNext());
            cursor.close();
        }

        // Exibir os filmes na ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, moviesList);
        listViewMovies.setAdapter(adapter);
    }

    // Filtrar os filmes de acordo com o gênero selecionado
    private void filterMoviesByGenre(String genre) {
        Cursor cursor = bancoHelper.listBooks();
        moviesList.clear();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String title = cursor.getString(cursor.getColumnIndex("title"));
                String yearLaunch = cursor.getString(cursor.getColumnIndex("yearLaunch"));
                int starsScore = cursor.getInt(cursor.getColumnIndex("starsScore"));
                String movieGenre = cursor.getString(cursor.getColumnIndex("genre"));

                if (genre.equals("Todos") || movieGenre.equals(genre)) {
                    String movie = id + " - " + title + " (" + yearLaunch + ") - " + starsScore + " estrelas - " + movieGenre;
                    moviesList.add(movie);
                }
            } while (cursor.moveToNext());
            cursor.close();
        }

        // Exibir os filmes filtrados na ListView
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, moviesList);
        listViewMovies.setAdapter(adapter);
    }

    // Exibir o diálogo de confirmação para excluir o filme
    private void showDeleteConfirmationDialog(final int movieId) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Você tem certeza que deseja excluir o filme?")
                .setPositiveButton("Excluir", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteMovie(movieId);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // Excluir o filme do banco de dados
    private void deleteMovie(int movieId) {
        int rowsDeleted = bancoHelper.deleteBook(movieId);
        if (rowsDeleted > 0) {
            Toast.makeText(ListMovies.this, "Filme excluído com sucesso!", Toast.LENGTH_SHORT).show();
            loadMoviesFromDatabase(); // Recarregar a lista de filmes após a exclusão
        } else {
            Toast.makeText(ListMovies.this, "Erro ao excluir filme", Toast.LENGTH_SHORT).show();
        }
    }
}
